Compile with command: clang pipe.c -o pipe
Run with command: ./pipe
